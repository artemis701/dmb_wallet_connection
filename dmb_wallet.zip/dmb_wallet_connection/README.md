# digitaldollar_wallet_connection
This is the wallet connection testing project for digital dollar chain.
